Administering Carbon
====================


Starting Carbon
---------------
Carbon can be started with the ``carbon-cache.py`` script::

    /opt/graphite/bin/carbon-cache.py start

This starts the main Carbon daemon in the background.  Now is a good time
to check the logs, located in ``/opt/graphite/storage/log/carbon-cache/``
for any errors.
