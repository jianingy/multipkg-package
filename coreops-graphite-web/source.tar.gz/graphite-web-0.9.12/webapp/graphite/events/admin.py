from django.contrib import admin
from graphite.events.models import Event

admin.site.register(Event)
